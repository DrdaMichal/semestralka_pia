package drdm.school.pia.dto;

/**
 * Basic interface for DTO
 */
public interface TransferObject {

    /**
     * ID getter
     * @return id of the DTO
     */
    String getId();

}
